package mypack;

public interface StudentDAO 
{
      void addStudent(Student ref);
}
